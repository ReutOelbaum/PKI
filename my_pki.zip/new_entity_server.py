import new_entity_interface
import GLOBALS

if __name__ == '__main__':

    # connect exiting ca- in order to be  ca by yourself/ get cert
    my_host = "127.3.1.0"
    my_port = 12344
    my_name = "ynet"
    new_entity_interface.run(my_host, my_port, my_name)